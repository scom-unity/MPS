##########################################################################################
# <summary>
# Enables the "Act as a Proxy" setting for multiple agents.
# </summary>
# <param name="rootMS">The name of the Root Management Server to connect to.</param>
# <param name="groupPathName">Pathname of the target group
#  ex: Microsoft.Windows.Server.2003.AD.DomainControllerComputerGroup
# </param>
##########################################################################################

$rootMS = "lab-lei-om01"
$groupPathName = "Microsoft.SystemCenter.AllComputersGroup"

#Initialize the OpsMgr Provider
add-pssnapin "Microsoft.EnterpriseManagement.OperationsManager.Client";
set-location "OperationsManagerMonitoring::";

#set Management Group context to the provided RMS
new-managementGroupConnection -ConnectionString:$rootMS;
set-location $rootMS;

$group = get-monitoringobject | where {$_.FullName -eq $groupPathName}

$relatedMonitoringObjects = $group.GetRelatedMonitoringObjects()

#Loops through all agents from the GetRelatedMontioringObjects method
foreach($monitoringObject in $relatedMonitoringObjects)
{	
	$agent = get-agent | where {$_.DisplayName -eq $monitoringObject.DisplayName}			
	if($agent -ne $null)
	{
		Write-Host "Enabling proxying for " + $agent.ComputerName
		$agent.ProxyingEnabled = $true
		$agent.ApplyChanges()
	}	
}